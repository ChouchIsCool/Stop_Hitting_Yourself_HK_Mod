# Stop_Hitting_Yourself

Mod that involves hitting yourself. Has one Charm edit. Heart -> Precise Aim

Made by me @chouchintosh on discord 
feel free to message me if you play it or have fun with it.
https://www.youtube.com/channel/UCKz5hYtjXKEppj9Y_SbXTOQ youtube too, but it's mostly mkw modding


A simple mod made to see if I could make a mod for this game without much difficulty. I'm grateful that the process is well documented enough to easily get into.